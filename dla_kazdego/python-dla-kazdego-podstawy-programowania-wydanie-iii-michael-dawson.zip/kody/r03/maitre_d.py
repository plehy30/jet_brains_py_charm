# Maitre d'
# Demonstruje traktowanie wartości jako warunku

print("Witaj w Chateau D' Smakosz")
print("Wydaje się, że tego wieczoru mamy prawie komplet gości.\n")

money = int(input("Ile złotych wsuniesz do kieszeni maitre d'? "))

if money:
    print("Och, przypomniałem sobie o wolnym stoliku. Proszę tędy.")
else:
    print("Proszę zaczekać. To może trochę potrwać.")

input("\n\nAby zakończyć program, naciśnij klawisz Enter.")

