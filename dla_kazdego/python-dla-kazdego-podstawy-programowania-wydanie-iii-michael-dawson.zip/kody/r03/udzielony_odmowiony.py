# Udzielony-odmówiony
# Demonstruje klauzulę else

print("Witaj w systemie firmy Bezpieczny Komputer SA")
print("-- bezpieczeństwo to podstawa naszego działania\n")

password = input("Wprowadź hasło: " )

if password == "sekret":
    print("Dostęp został udzielony")
else:
    print("Odmowa dostępu")

input("\n\nAby zakończyć program, naciśnij klawisz Enter.")
