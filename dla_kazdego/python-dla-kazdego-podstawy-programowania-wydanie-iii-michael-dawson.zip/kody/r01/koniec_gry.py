# Koniec gry
# Przykład użycia funkcji print

print("Koniec gry")

input("\n\nAby zakończyć program, naciśnij klawisz Enter.")
