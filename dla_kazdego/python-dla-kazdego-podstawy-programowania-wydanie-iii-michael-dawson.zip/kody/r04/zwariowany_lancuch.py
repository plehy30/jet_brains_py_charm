# Zwariowany łańcuch
# Demonstruje użycie pętli for z łańcuchem znaków
word = input("Wprowadź jakieś słowo: ")

print("\nOto poszczególne litery Twojego słowa:")
for letter in word:
    print(letter)

input("\n\nAby zakończyć program, naciśnij klawisz Enter.")
