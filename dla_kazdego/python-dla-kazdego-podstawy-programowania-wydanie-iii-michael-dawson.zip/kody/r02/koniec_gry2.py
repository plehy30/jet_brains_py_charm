# Koniec gry - wersja 2
# Demonstruje użycie cudzysłowów w łańcuchach znaków
print("Program 'Koniec gry' 2.0")

print("Taki sam", "komunikat", "jak przedtem,")

print("tylko",
      "nieco",
      "większy.")

print("Oto", end=" ")
print("on...")

print(
        """
        _  __   ____    _   _   _____   ______    _____ 
       | |/ /  / __ \  | \ | | |_   _| |  ____|  / ____|
       | ' /  | |  | | |  \| |   | |   | |__    | |     
       |  <   | |  | | | . ` |   | |   |  __|   | |     
       | . \  | |__| | | |\  |  _| |_  | |____  | |____ 
       |_|\_\  \____/  |_| \_| |_____| |______|  \_____|
         
         _____   _____   __     __
       /  ____| |  __ \  \ \   / /
       | |  __  | |__) |  \ \_/ / 
       | | |_ | |  _  /    \   /  
       | |__| | | | \ \     | |   
        \_____| |_|  \_\    |_|  

        """
     )

input("\n\nAby zakończyć program, naciśnij klawisz Enter.")
