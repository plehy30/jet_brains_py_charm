# Zabawne podziękowania
# Demonstruje sekwencje specjalne

print("\t\t\tZabawne podziękowania")

print("\t\t\t \\ \\ \\ \\ \\ \\ \\ \\ \\ \\")
print("\t\t\t      napisał")
print("\t\t\t  Michael Dawson")
print("\t\t\t  \\ \\ \\ \\ \\ \\ \\")

print("\nSpecjalne podziękowania należą się:")
print("mojemu fryzjerowi,", end=" ")
print("Henry\'emu \'Wielkiemu\', który nigdy nie mówi \"nie da się\".")

# dzwonek systemowy
print("\a")

input("\n\nAby zakończyć program, naciśnij klawisz Enter.")
