# Osobisty pozdrawiacz
# Demonstruje pobieranie danych wprowadzanych przez użytkownika

name = input("Cześć. Jak masz na imię? ")

print(name)

print("Cześć,", name)

input("\n\nAby zakończyć program, naciśnij klawisz Enter.")
