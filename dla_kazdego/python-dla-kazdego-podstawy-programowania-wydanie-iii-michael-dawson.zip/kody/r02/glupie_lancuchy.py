# Głupie łańcuchy
# Demonstruje konkatenację i powielanie łańcuchów

print("Możesz dokonać konkatenacji dwóch " + "łańcuchów za pomocą operatora '+'.")

print("\nTen łańcuch " + "może nie " + "sprawiać wiel" + "kiego wrażenia. " \
      + "Ale " + "pewnie nie wiesz," + " że jest\n" + "to jeden napraw" \
      + "d" + "ę" + " długi łańcuch, utworzony przez konkatenację " \
      + "aż " + "dwudziestu dwu\n" + "różnych łańcuchów i rozbity na " \
      + "sześć wierszy." + " Jesteś pod" + " wrażeniem tego faktu?\n" \
      + "Dobrze, ten " + "jeden " + "długi" + " łańcuch właśnie się skończył!")

print("\nJeśli jakiś łańcuch naprawdę Ci się podoba, możesz go powtórzyć.")
print("Kto na przykład nie lubi lodów?  Masz rację, nikt. Ale jeśli naprawdę ")
print("je lubisz, powinieneś to wyrazić w adekwatny sposób:")
print(10 * "Lody!")

input("\n\nAby zakończyć program, naciśnij klawisz Enter.")

