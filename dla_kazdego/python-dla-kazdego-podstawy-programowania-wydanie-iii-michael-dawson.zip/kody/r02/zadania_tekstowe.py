# Zadania tekstowe
# Liczby i działania matematyczne

print("Ciężarna hipopotamica ważąca 1500 kg rodzi 45-kilogramowe młode,")
print("ale potem zjada 25 kg paszy. Ile wynosi jej nowa waga?")
input("Aby się dowiedzieć, naciśnij klawisz Enter.")
print("1500 - 45 + 25 =", 1500 - 45 + 25)

print("Poszukiwacz przygód wraca z udanej wyprawy i kupuje każdemu ze swoich")
print("6 towarzyszy 3 butelki piwa. Ile butelek zostało zakupionych?")
input("Aby się dowiedzieć, naciśnij klawisz Enter.")
print("6 * 3 =", 6 * 3)

print("Należność za obiad w restauracji wynosi razem z napiwkiem 159 zł, a Ty")
print("postanawiasz ze swoimi przyjaciółmi podzielić ją na 4 równe części. Ile")
print("każde z Was będzie musiało zapłacić?")
input("Aby się dowiedzieć, naciśnij klawisz Enter.")
print("159 / 4 =", 159 / 4)

print("\nGrupa 4 piratów znajduje skrzynię, a w niej 107 złotych monet, i")
print("postanawia podzielić zdobycz po równo. Ile monet otrzyma każdy z nich?")
input("Aby się dowiedzieć, naciśnij klawisz Enter.")
print("107 // 4 =", 107 // 4)

print("\nTa sama grupa 4 piratów dzieli między siebie po równo 107 złotych")
print("monet ze znalezionej skrzyni. Ile monet zostanie po podziale?")
input("Aby się dowiedzieć, naciśnij klawisz Enter.")
print("107 % 4 =", 107 % 4)

input("\n\nAby zakończyć program, naciśnij klawisz Enter.")
