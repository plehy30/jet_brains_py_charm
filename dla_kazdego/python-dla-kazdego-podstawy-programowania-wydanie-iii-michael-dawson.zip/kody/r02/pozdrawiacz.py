# Pozdrawiacz
# Demonstruje użycie zmiennej

name = "Ludwik"

print(name)

print("Cześć,", name)

input("\n\nAby zakończyć program, naciśnij klawisz Enter.")
