# Prosty interfejs GUI
# Demonstruje tworzenie okna

from tkinter import *

# utwórz okno główne
root = Tk()

# zmodyfikuj okno
root.title("Prosty interfejs GUI")
root.geometry("225x100")

# uruchom pętlę zdarzeń 
root.mainloop()
